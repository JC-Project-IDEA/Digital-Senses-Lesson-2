let img;

function preload() {
  img = loadImage("img.png");
}

function setup() {
  createCanvas(512,512);
  image(img, 0, 0);
}