let img;

function preload() {
  img = loadImage("https://cdn.shopify.com/s/files/1/1832/0821/files/catshark.jpg?v=1649869148");
}

function setup() {
  createCanvas(512,512);
  image(img, 0, 0,width,height);
}