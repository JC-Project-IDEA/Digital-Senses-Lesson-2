let img;

function preload(){
  img = loadImage('TaiPo_Image.jpg');
}

function setup(){
  createCanvas(400,400);
  background(220);
  tint('#ED225D');
  image(img,0,0,400,400); 
  filter(POSTERIZE, 5);
}
