let video;

function setup() {
  createCanvas(320, 240);
  video = createVideo("light.mp4");
  video.size(320, 240);
  video.volume(0);
  video.loop();
  video.hide(); 
}

function draw() {
  let img = video.get();
  image(img, 0, 0);   
}

