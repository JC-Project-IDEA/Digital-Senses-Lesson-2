let captureButton;

function setup() {
  createCanvas(640, 360);
  captureButton = createButton("draw");
  captureButton.mousePressed(drawEllipse);
  background(0);
}

function drawEllipse() {
  fill(random(0,255),random(0,255),random(0,255));
  ellipse(random(0,width),random(0,height),30,30);
}

