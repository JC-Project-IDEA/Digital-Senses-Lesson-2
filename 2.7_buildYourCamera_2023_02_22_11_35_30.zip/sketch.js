let capture;
let captureButton;

function setup() {
  createCanvas(640, 360);
  capture = createCapture(VIDEO);
  captureButton = createButton("capture");
  captureButton.mousePressed(takePicture);
  capture.hide();
}

function draw() {
  background(0);
  image(capture, 0, 0);
}

function takePicture() {
  save();
}

